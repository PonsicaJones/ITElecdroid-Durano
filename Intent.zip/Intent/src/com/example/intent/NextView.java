package com.example.intent;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class NextView extends Activity{
	
	TextView text;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.nextview);
		text = (TextView) this.findViewById(R.id.textView1);
		Bundle b = this.getIntent().getExtras();
		String text = b.getString("text");
		this.text.setText(text);
	}
	
}
