package com.example.simplejudgeapp;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class ListJudge extends Activity implements OnClickListener{
	ArrayList<Item> list = new ArrayList<Item>();
	ListView lv;
	MyAdapter adapter;
	AdapterView.AdapterContextMenuInfo info;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listlayout);
		
		lv = (ListView) this.findViewById(R.id.listView1);
		
	    adapter = new MyAdapter(this,list);
        this.lv.setAdapter(adapter);
        this.registerForContextMenu(lv);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
        retrieve();
	}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
   	public boolean onOptionsItemSelected(MenuItem item) {
   		// TODO Auto-generated method stub
   		try{
   			Intent intent = new Intent(this,Add3.class);
   			this.startActivity(intent);
   			this.finish();
   		}catch(Exception e){
   			e.printStackTrace();
   		}
   		return super.onOptionsItemSelected(item);
   	}
    public void retrieve(){
		
		 try {
				URL url = new URL("http://10.0.2.2/androidweb/listjudge.php");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				
				InputStream is = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				int c = 0;
				while((c=is.read())!=-1){
					sb.append((char)c);
				}
				
				conn.disconnect();
				is.close();
				
				String jsonString = sb.toString();
				JSONObject json = new JSONObject(jsonString);
				JSONArray teamArray = json.getJSONArray("team");

				for(int i = 0; i < teamArray.length(); i++){
					JSONObject team = (JSONObject) teamArray.get(i);
					Item item = new Item();
					item.setId(team.getString("judge_id"));
					item.setName(team.getString("judge_name"));
		
					list.add(item);
				}
					this.adapter.notifyDataSetChanged();
			        			
				Toast.makeText(this, teamArray.length()+"", Toast.LENGTH_LONG).show();
			} catch (MalformedURLException e) {
				Toast.makeText(this, "m", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (IOException e) {
				Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        adapter.notifyDataSetChanged();
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		try{
			int id = item.getItemId();
			switch(id){
			case R.id.update:
				
//				String itemSelectedName = source.get(info.position).getName();
//				Uri uri = source.get(info.position).getUri();
//				int selectedid = source.get(info.position).getId();
//				
//				Intent intent = new Intent(ListViewClass.this,UpdatePerson.class);
//
//				intent.putExtra("updatename", itemSelectedName);
//				intent.putExtra("updateimage", uri);
//				intent.putExtra("id", selectedid);
//				startActivityForResult(intent,111);
				break;
			case R.id.delete:

//					dialog.show();
					AlertDialog.Builder builder = new AlertDialog.Builder(ListJudge.this);
		
					builder.setTitle("Message");
					builder.setMessage("Are you sure you want to delete"+list.get(info.position).getName()+" "+list.get(info.position).getId()+"??");
					builder.setPositiveButton("Ok", this);
					builder.setNegativeButton("Cancel", this);
					
					AlertDialog dialog = builder.create();
						dialog.show();				
				break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return super.onContextItemSelected(item);
	}


	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		getMenuInflater().inflate(R.menu.contextmenu, menu);
		info = (AdapterContextMenuInfo) menuInfo;
		String itemSelectedName = list.get(info.position).getName();
		String itemSelectedId = list.get(info.position).getId()+" ";
		menu.setHeaderIcon(R.drawable.ic_launcher);
		menu.setHeaderTitle(itemSelectedName+ " id: "+itemSelectedId);
	}
	@Override
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
		try{
			switch(arg1){
			case DialogInterface.BUTTON_POSITIVE:
			
					Toast.makeText(this, list.get(info.position).getId()+"", Toast.LENGTH_LONG).show();
					try {
						String selectedItem = list.get(info.position).getId();
						URL url = new URL("http://10.0.2.2/androidweb/deleteJudge.php?idno="+selectedItem);
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						
						InputStream is = conn.getInputStream();
						StringBuffer sb = new StringBuffer();
						int c = 0;
						
						
						while((c=is.read())!=-1){
							sb.append((char)c);
						}
						Toast.makeText(ListJudge.this, sb.toString(), Toast.LENGTH_LONG).show();
						
						Intent intent = new Intent(ListJudge.this,ListJudge.class);
						startActivity(intent);
						finish();
						conn.disconnect();
						is.close();
						
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					Toast.makeText(this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
		
					adapter.notifyDataSetChanged();
			break;
			case DialogInterface.BUTTON_NEGATIVE:
				arg0.dismiss();
			break;
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
   
}
