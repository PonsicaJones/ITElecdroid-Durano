package com.example.simplejudgeapp;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Add2 extends Activity{
	Button btnAdd;
	EditText txtName;
	String str = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addlayout);

		this.txtName = (EditText) this.findViewById(R.id.editText1);

		this.btnAdd = (Button) this.findViewById(R.id.button1);

		btnAdd.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				URL url = null;
				String name= txtName.getText().toString();
	
				try {

					url=new URL("http://10.0.2.2/androidweb/addGroup.php?name="+name);
				
					HttpURLConnection conn=(HttpURLConnection) url.openConnection();
					//receive the server response
					InputStream is=conn.getInputStream();
					int c=0;
					StringBuffer sb=new StringBuffer();
					while((c=is.read())!=-1){					
						sb.append((char)c);					
					}
					//after receive, close all streams
					is.close();
					//disconnect the server
					conn.disconnect();
					
					
					Toast.makeText(Add2.this, sb.toString(), Toast.LENGTH_SHORT).show();
										
							Intent intent = new Intent(Add2.this, ListGroup.class);
							startActivity(intent);
							finish();

//						new ListLang().retrieve();
					
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
								
			}
		});
	}
	
}