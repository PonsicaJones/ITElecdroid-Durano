package com.example.simplejudgeapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.Toast;

public class MyRatings extends Activity {
	
	WebView wv;
	static int judge_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.myratings);
		this.wv=(WebView) this.findViewById(R.id.webView1);
		Intent intent = getIntent();
		Bundle b = intent.getExtras();
		judge_id = Integer.parseInt(b.getString("judge_id"));
		String ipadd=Sessions.getIpAddress();
		String url="http:10.0.2.2/hackaton/getmyratings.php?judge_id="+judge_id;
		Toast.makeText(this, judge_id+"", Toast.LENGTH_LONG).show();
		this.wv.loadUrl(url);	
	}	
}