package com.example.simplejudgeapp;

public class Sessions {
	
static String ipAddress;
	
	public static void setIpAdd(String ip)
	{
		Sessions.ipAddress = "10.0.2.2";
	}
	
	public static String getIpAddress()
	{
		return Sessions.ipAddress;
	}

}
