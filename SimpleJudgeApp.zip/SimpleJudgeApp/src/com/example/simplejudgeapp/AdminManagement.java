package com.example.simplejudgeapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminManagement extends Activity{
	Button btnGroup, btnJudge, btnCreateria;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.managementlayout);
		
		this.btnGroup = (Button) this.findViewById(R.id.button1);
		this.btnJudge = (Button) this.findViewById(R.id.button2);
//		this.btnCreateria = (Button) this.findViewById(R.id.button3);
		
		btnGroup.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(new Intent(AdminManagement.this, ListGroup.class));
			}
		});
			
		btnJudge.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(new Intent(AdminManagement.this, ListJudge.class));
			}
		});
		
//		btnCreateria.setOnClickListener(new View.OnClickListener() {
//			
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				startActivity(new Intent(AdminManagement.this, ListCreateria.class));
//			}
//		});
	}	
}
