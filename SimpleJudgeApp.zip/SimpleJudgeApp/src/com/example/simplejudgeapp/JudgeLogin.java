package com.example.simplejudgeapp;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class JudgeLogin extends Activity implements OnClickListener{
	EditText txtUsername, txtPassword;
	Button btnLogin;
	String id = "";
	String judge_id;
	String name = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.admin);
		
		 this.txtUsername = (EditText) this.findViewById(R.id.editText1);
	        this.txtPassword = (EditText) this.findViewById(R.id.editText2);
	        
	        this.btnLogin = (Button) this.findViewById(R.id.button1);
	        
	        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
	        StrictMode.setThreadPolicy(policy);
	        btnLogin.setOnClickListener(this);
	        
	        Intent intent = getIntent();
	        Bundle b = intent.getExtras();
//	        id = b.getString("id");
	        judge_id= b.getString("judge_id");
	        name = b.getString("name");
	        
	     					   			
	}
	@Override
	public void onClick(View arg0) {
		int id=arg0.getId();
		switch(id){
		case R.id.button1:
			
			String username=this.txtUsername.getText().toString();
			String password=this.txtPassword.getText().toString();

			
			try {
				URL url=new URL("http://10.0.2.2/androidweb/loginjudge.php?username="+username+"&password="+password);
				HttpURLConnection conn=(HttpURLConnection) url.openConnection();
				//receive the server response
				InputStream is=conn.getInputStream();
				int c=0;
				StringBuffer sb=new StringBuffer();
				while((c=is.read())!=-1){					
					sb.append((char)c);					
				}
				//after receive, close all streams
				is.close();
				//disconnect the server
				conn.disconnect();
				
				Toast.makeText(this, sb.toString(), Toast.LENGTH_SHORT).show();

					if(sb.toString().equals("Login Successfully")){
						Intent intent = new Intent(JudgeLogin.this,Group.class);
     					intent.putExtra("id", id);
     					intent.putExtra("judge_id", judge_id);
     					intent.putExtra("groupname", name);
     					startActivityForResult(intent,111);  
     					this.finish();
					}
					
			
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				Toast.makeText(this, "i", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
			
		
		}
		
	}
}
