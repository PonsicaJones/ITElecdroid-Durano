package com.example.simplejudgeapp;


import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Group extends Activity{
	ArrayList<Item> list = new ArrayList<Item>();
	ListView lv;
	MyAdapter adapter;
	String judge_id ="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listlayout);
		
		lv = (ListView) this.findViewById(R.id.listView1);
		
	    adapter = new MyAdapter(this,list);
        this.lv.setAdapter(adapter);
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        judge_id = b.getString("judge_id");
        String name = b.getString("name");
        Toast.makeText(this, judge_id, Toast.LENGTH_LONG).show();
        this.lv.setOnItemClickListener(new OnItemClickListener(){
     			@Override
     			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
     					long arg3) {
     					Intent intent = new Intent(Group.this,GroupScore.class);
     					intent.putExtra("id", list.get(arg2).getId()+"");
     					intent.putExtra("judge_id", judge_id);
     					intent.putExtra("groupname", list.get(arg2).getName()+"");
     					startActivityForResult(intent,111);     
     				
     			}});
        retrieve();
	}
	
	   @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	        getMenuInflater().inflate(R.menu.mratings, menu);      
	        return true;
	    }
    
    @Override
   	public boolean onOptionsItemSelected(MenuItem item) {
   		// TODO Auto-generated method stub
   		try{
   			switch(item.getItemId()){
   			case R.id.rate:
	   			Intent intent = new Intent(this,MyRatings.class);	   			
	   			intent.putExtra("judge_id", judge_id);
	   			startActivityForResult(intent,11111);  	   		
   			break;
   			}
   		}catch(Exception e){
   			e.printStackTrace();
   		}
   		return super.onOptionsItemSelected(item);
   	}
	public void retrieve(){
		
		 try {
				URL url = new URL("http://10.0.2.2/androidweb/listgroup.php");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				
				InputStream is = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				int c = 0;
				while((c=is.read())!=-1){
					sb.append((char)c);
				}
				
				conn.disconnect();
				is.close();
				
				String jsonString = sb.toString();
				JSONObject json = new JSONObject(jsonString);
				JSONArray teamArray = json.getJSONArray("team");

				for(int i = 0; i < teamArray.length(); i++){
					JSONObject team = (JSONObject) teamArray.get(i);
					Item item = new Item();
					item.setId(team.getString("team_id"));
					item.setName(team.getString("team_name"));
					list.add(item);
				}
					this.adapter.notifyDataSetChanged();
			        			
				Toast.makeText(this, teamArray.length()+"", Toast.LENGTH_LONG).show();
			} catch (MalformedURLException e) {	
				Toast.makeText(this, "m", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (IOException e) {
				Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        adapter.notifyDataSetChanged();
	}
   
}
