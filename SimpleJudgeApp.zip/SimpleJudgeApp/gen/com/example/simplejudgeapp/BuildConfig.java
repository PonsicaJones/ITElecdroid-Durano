/** Automatically generated file. DO NOT MODIFY */
package com.example.simplejudgeapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}