package com.example.weatherapp;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements TextWatcher {
	TextView weathertype, cityName, temperature, humidity;
	ImageView iv;
	EditText txtSearch;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.iv = (ImageView) this.findViewById(R.id.imageView1);
        this.weathertype = (TextView) this.findViewById(R.id.textView1);
        this.cityName = (TextView) this.findViewById(R.id.textView2);
        this.temperature = (TextView) this.findViewById(R.id.textView3);
        this.humidity = (TextView) this.findViewById(R.id.textView4);
        this.txtSearch = (EditText) this.findViewById(R.id.editText1);
        this.txtSearch.addTextChangedListener(this);
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void afterTextChanged(Editable arg0) {
		// TODO Auto-generated method stub
	    try {
        	String search = txtSearch.getText().toString();
			URL url = new URL("http://api.openweathermap.org/data/2.5/weather?q="+search+"&appid=4defc46fe1ea60f4eb14565fde8ff87b");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			StringBuffer sb = new StringBuffer();
			InputStream is = conn.getInputStream();
			
			int c = 0;
			
			while((c = is.read()) != -1){
				sb.append((char)c);
			}
			
			is.close();
			conn.disconnect();
			
			
			JSONObject json = new JSONObject(sb.toString());
			JSONArray weather = json.getJSONArray("weather");
			JSONObject desc = weather.getJSONObject(0);
			
			String ds = desc.getString("description");
			String icon = desc.getString("icon");
			
			String city = json.getString("name");
			JSONObject main = json.getJSONObject("main");
			
			String temp = main.getString("temp");
			String hum = main.getString("humidity");
			
			double celcius = Double.parseDouble(temp)-272.3;
			weathertype.setText(ds);
			cityName.setText(city);
			humidity.setText(hum+"%");
			temperature.setText(String.format("%.2f", celcius)+"�C");
			
		    URL urlIcon = new URL("http://openweathermap.org/img/w/"+icon+".png");
			HttpURLConnection connIcon = (HttpURLConnection) urlIcon.openConnection();
			
			//StringBuffer sbIcon = new StringBuffer();
			InputStream isIcon = connIcon.getInputStream();
			//int cIcon = 0;
			
//			while((cIcon = isIcon.read()) != -1){
//				sbIcon.append((char)cIcon);
//			}
			
			Bitmap bmp = BitmapFactory.decodeStream(isIcon);					
			iv.setImageBitmap(bmp);
			
			isIcon.close();
			connIcon.disconnect();
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}


	@Override
	public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
			int arg3) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}
    
}
