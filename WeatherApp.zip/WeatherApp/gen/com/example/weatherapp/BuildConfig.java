/** Automatically generated file. DO NOT MODIFY */
package com.example.weatherapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}