package com.example.studentinfo;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

 public class MainActivity extends Activity implements OnClickListener, OnItemSelectedListener, OnItemClickListener {
	ArrayList<Student> model = new ArrayList<Student>();
	
    //ArrayList<String> user = new ArrayList<String>();
    //ArrayList<String> pass = new ArrayList<String>();
    
	ArrayAdapter<Student> adapter = null;
	EditText txtIdno, txtName;
	Spinner course;
	Button btnOK, btnCancel;
	RadioGroup grpSex;
	String selectedCourse;
	String selectedSex;
	ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        this.txtIdno = (EditText) this.findViewById(R.id.editText1);
        this.txtName = (EditText) this.findViewById(R.id.editText2);
        this.course = (Spinner) this.findViewById(R.id.spinner1);
        this.grpSex = (RadioGroup) this.findViewById(R.id.radioGroup1);
        this.btnOK = (Button) this.findViewById(R.id.button1);
        this.btnCancel = (Button) this.findViewById(R.id.button2);
        
        
        course.setOnItemSelectedListener(this);
        btnOK.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        
        
        list = (ListView) this.findViewById(R.id.listView1);
        list.setOnItemClickListener(this);
        adapter = new ArrayAdapter<Student>(this,android.R.layout.simple_list_item_1,model);
        
        list.setAdapter(adapter);
      
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onClick(View v) {
		
		int id = v.getId();
		
		switch(id){
		case R.id.button1: 
			Student s = new Student();
			
			String idno = txtIdno.getText().toString();
			String name = txtName.getText().toString();
			int sexId = grpSex.getCheckedRadioButtonId();
			RadioButton sex = (RadioButton) this.findViewById(sexId);
			selectedSex = sex.getText().toString();
			s.setName(name);
			s.setIdno(idno);
			s.setCourse(selectedCourse);
			s.setGender(selectedSex);
			if((name.length() > 0 && idno.length() > 0 )){
//			    String student = "IDNO:\t "+idno+"\n"+
//						     "NAME:\t "+s.getName()+"\n"+
//						     "COURSE:\t "+s.getCourse()+"\n"+
//						     "SEX:\t "+s.getGender();
//				AlertDialog.Builder builder = new AlertDialog.Builder(this);
//				builder.setTitle("Student Information");
//				builder.setMessage(student);
//				builder.setNegativeButton("Okey", null);
//				AlertDialog dialog = builder.create();
//				dialog.show();
				adapter.add(s);
			}
			else 
				Toast.makeText(this, "Fill all the Fields", Toast.LENGTH_SHORT).show();
			
			break;
		case R.id.button2:
			clear();
			break;
		}
		// TODO Auto-generated method stub
		
	}
	public void clear(){
		this.txtIdno.setText("");
		this.txtName.setText("");
		course.setSelection(0);
		
	}

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub
		selectedCourse = course.getItemAtPosition(arg2).toString();
	}


	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		String[] ex = list.getItemAtPosition(arg2).toString().split(" ");
		String student = "IDNO:\t "+ex[0]+"\n"+
			     "NAME:\t "+ex[1]+"\n"+
			     "COURSE:\t "+ex[2]+"\n"+
			     "SEX:\t "+ex[3];
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Student's Info");
		builder.setMessage(student);
		builder.setNeutralButton("ok", null);
		
		AlertDialog dialog = builder.create();
			dialog.show();
	}   

}
