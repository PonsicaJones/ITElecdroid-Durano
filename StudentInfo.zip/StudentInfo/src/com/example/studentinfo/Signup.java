package com.example.studentinfo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Signup extends Activity implements OnClickListener{
	Button btnSignup;
	EditText password1;
	EditText password2;
	EditText username;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.signup);
		
		this.btnSignup = (Button) this.findViewById(R.id.button1);
		this.password1 = (EditText) this.findViewById(R.id.editText2);
		this.password2 = (EditText) this.findViewById(R.id.editText3);
		this.username = (EditText) this.findViewById(R.id.editText1);
		
		this.btnSignup.setOnClickListener(this);
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		int id = arg0.getId();
		
		switch(id){
		case R.id.button1:
			//String u = username.getText().toString();
			//String p1 = password1.getText().toString();
			//String p2 = password2.getText().toString();
					
			//if(p1.equals(p2)){
				Toast.makeText(this," updating...stay tune", Toast.LENGTH_SHORT).show();
		//	}					
			break;
		}
	}
	
}
