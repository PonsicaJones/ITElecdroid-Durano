package com.example.studentinfo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Login extends Activity implements OnClickListener{
	Button btn;
	TextView txtSign;
	EditText user;
	EditText pass;
    String pass1,user1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.log);
		
		this.btn = (Button) this.findViewById(R.id.button1);
		this.btn.setOnClickListener(this);
		this.txtSign = (TextView) this.findViewById(R.id.textView1);
		txtSign.setOnClickListener(this);
		this.user = (EditText) this.findViewById(R.id.editText1);
		this.pass = (EditText) this.findViewById(R.id.editText2);
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		//Toast.makeText(this, "im here", Toast.LENGTH_SHORT).show();
		int id = arg0.getId();
		switch(id){
		case R.id.button1:
			String username = this.user.getText().toString();
			String password = this.pass.getText().toString();
		//	Toast.makeText(this, pass1+user1+" ", Toast.LENGTH_SHORT).show();
			if(username.equals("admin") && password.equals("123")){
				Intent intent = new Intent(this,MainActivity.class);
				startActivityForResult(intent, 0);
			}else
				Toast.makeText(this, "Wrong Username or Password", Toast.LENGTH_SHORT).show();
			break;
	    case R.id.textView1:
			Intent intent = new Intent(this,Signup.class);
			startActivityForResult(intent, 0);
	    	break;
		}
		
	}

}
