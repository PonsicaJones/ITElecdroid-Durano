package com.example.androidexam;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class QuestionList extends Activity implements  OnItemClickListener{
	ArrayList<String> list = new ArrayList<String>();
	ArrayAdapter<String> adapter;
	 ListView lv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.questionlistlayout);
		
		this.lv = (ListView) this.findViewById(R.id.listView1);
		this.adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
		this.lv.setAdapter(adapter);
		
	
		this.lv.setOnItemClickListener(this);
		
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
        retrieve();
		
	}
	public void retrieve(){
		
		 try {
				URL url = new URL("http://10.0.2.2/androidweb/question.php");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				
				InputStream is = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				int c = 0;
				while((c=is.read())!=-1){
					sb.append((char)c);
				}
				
				conn.disconnect();
				is.close();
				
				JSONObject json = new JSONObject(sb.toString());
				JSONArray questionArray = json.getJSONArray("question");
								
	
				
				for(int i = 0; i < questionArray.length(); i++){
					JSONObject question = (JSONObject) questionArray.get(i);
					String question1 = question.getString("qid");
					list.add(question1);   
				}
				
				adapter.notifyDataSetChanged();
			//	Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show();
			} catch (MalformedURLException e) {
				Toast.makeText(this, "m", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (IOException e) {
				Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
	        
	    
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		Intent intent = new Intent(QuestionList.this, Question.class);
		intent.putExtra("title", list.get(arg2));
		startActivityForResult(intent,11);
	}
}
