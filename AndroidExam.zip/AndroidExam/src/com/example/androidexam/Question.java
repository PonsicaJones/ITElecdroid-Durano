package com.example.androidexam;




import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Question extends Activity{

	
	ListView lv;
	int titleId ;
	TextView txtQuestion, txtChoice1,txtChoice2,txtChoice3,txtChoice4;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.questionlayout);
		
		Intent intent = getIntent();
		Bundle b = intent.getExtras();
		String title = b.getString("title");
		titleId = Integer.parseInt(title);
		
		this.txtQuestion = (TextView) this.findViewById(R.id.textView1);
		this.txtChoice1 = (TextView) this.findViewById(R.id.textView2);
		this.txtChoice2 = (TextView) this.findViewById(R.id.textView3);
		this.txtChoice3 = (TextView) this.findViewById(R.id.textView4);
		this.txtChoice4 = (TextView) this.findViewById(R.id.textView5);
		retrieve();
	}
	
	public void retrieve(){
		
		 try {
				URL url = new URL("http://10.0.2.2/androidweb/question.php");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				
				InputStream is = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				int c = 0;
				while((c=is.read())!=-1){
					sb.append((char)c);
				}
				
				conn.disconnect();
				is.close();
				
				JSONObject json = new JSONObject(sb.toString());
				JSONArray questionArray = json.getJSONArray("question");

				JSONObject question = (JSONObject) questionArray.get(titleId-1);
				
				String question1 = question.getString("question");

				String choice1 = question.getString("choice1");
				String choice2 = question.getString("choice2");
				String choice3 = question.getString("choice3");
				String choice4 = question.getString("choice4");
//				
				this.txtQuestion.setText(question1);
				this.txtChoice1.setText(choice1);
				this.txtChoice2.setText(choice2);
				this.txtChoice3.setText(choice3);
				this.txtChoice4.setText(choice4);
				Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show();
			} catch (MalformedURLException e) {
				Toast.makeText(this, "m", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (IOException e) {
				Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (JSONException e) {
				Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} 
	        
	    
	}
	
}
