package com.example.jsonparsing;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {
	ArrayList<Student> list = new ArrayList<Student>();
	ItemAdapter adapter;
	ListView lv;
	String jsonString = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) this.findViewById(R.id.listView1);
        
        adapter = new ItemAdapter(list,this);
        this.lv.setAdapter(adapter);
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
        try {
			URL url = new URL("http://10.0.2.2/androidweb/listforandroid.php");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			
			InputStream is = conn.getInputStream();
			StringBuffer sb = new StringBuffer();
			int c = 0;
			while((c=is.read())!=-1){
				sb.append((char)c);
			}
			
			conn.disconnect();
			is.close();
			
			jsonString = sb.toString();
			JSONObject json = new JSONObject(jsonString);
			JSONArray studentArray = json.getJSONArray("student");

			for(int i = 0; i < studentArray.length(); i++){
				JSONObject student = (JSONObject) studentArray.get(i);
					Student s = new Student();
				s.setIdno(student.getString("idno"));
					s.setLastname(student.getString("familyname"));
					s.setFirstname(student.getString("givenname"));
					s.setCourse(student.getString("course"));
					s.setYear(student.getString("yearlevel"));
					s.setCampus(student.getString("campus"));
					list.add(s);
			}
				adapter.notifyDataSetChanged();
		        			
			Toast.makeText(this, studentArray.length()+"", Toast.LENGTH_LONG).show();
		} catch (MalformedURLException e) {
			Toast.makeText(this, "m", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (IOException e) {
			Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);      
        return true;
    }
    
    
}
