-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 27, 2017 at 08:40 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ictcongress`
--

-- --------------------------------------------------------

--
-- Table structure for table `createria`
--

CREATE TABLE IF NOT EXISTS `createria` (
  `crea_id` int(11) NOT NULL AUTO_INCREMENT,
  `crea_name` varchar(50) NOT NULL,
  `crea_total` int(11) NOT NULL,
  PRIMARY KEY (`crea_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `createria`
--

INSERT INTO `createria` (`crea_id`, `crea_name`, `crea_total`) VALUES
(1, 'createria 1', 30),
(2, 'createria 2', 60),
(3, 'vreater', 40);

-- --------------------------------------------------------

--
-- Table structure for table `judge`
--

CREATE TABLE IF NOT EXISTS `judge` (
  `judge_id` int(11) NOT NULL AUTO_INCREMENT,
  `judge_name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `voted` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`judge_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `judge`
--

INSERT INTO `judge` (`judge_id`, `judge_name`, `status`, `voted`, `username`, `password`) VALUES
(1, 'gerson', 0, 0, 'judge1', 'judge1'),
(2, 'angelica', 0, 0, 'judge2', 'judge2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_scoresheet`
--

CREATE TABLE IF NOT EXISTS `tbl_scoresheet` (
  `score_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `judge_id` int(11) NOT NULL,
  `c1` int(11) NOT NULL,
  `c2` int(11) NOT NULL,
  `c3` int(11) NOT NULL,
  PRIMARY KEY (`score_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_scoresheet`
--

INSERT INTO `tbl_scoresheet` (`score_id`, `group_id`, `judge_id`, `c1`, `c2`, `c3`) VALUES
(1, 1, 1, 40, 35, 25),
(2, 2, 1, 30, 30, 20),
(3, 3, 1, 30, 20, 25);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE IF NOT EXISTS `tbl_student` (
  `idno` varchar(10) NOT NULL,
  `familyname` varchar(50) NOT NULL,
  `givenname` varchar(50) NOT NULL,
  `course` varchar(10) NOT NULL,
  `yearlevel` varchar(5) NOT NULL,
  `campus` varchar(10) NOT NULL,
  `attended` int(11) NOT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`idno`, `familyname`, `givenname`, `course`, `yearlevel`, `campus`, `attended`) VALUES
('0001', 'DURANO', 'DENNIS', 'BSIT', '5', 'MAIN', 1),
('0002', 'HELLO', 'WORLD', 'BSIT', '4', 'MAIN', 0),
('0003', 'ALPHA', 'BRAVO', 'BSCS', '3', 'UCLM', 0),
('0004', 'CHARLIE', 'DELTA', 'ACT', '2', 'MAIN', 0),
('0006', 'WHISKEY', 'TANGO', 'ACT', '1', 'MAIN', 0),
('0007', 'HOTEL', 'INDIA', 'ACT', '2', 'UCLM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teamm`
--

CREATE TABLE IF NOT EXISTS `teamm` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(50) NOT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `teamm`
--

INSERT INTO `teamm` (`team_id`, `team_name`) VALUES
(1, '0-wan-0'),
(2, 'NotToday'),
(3, 'Team-Ex'),
(4, 'Gwapo');
