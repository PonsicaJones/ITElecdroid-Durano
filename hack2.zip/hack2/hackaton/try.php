<?php
   include 'dbconn.php';
   
   $team=ret_user();
   
    foreach($team as $t){
	   foreach($t as $n){
	      echo $n.'<br>';
	   }
	}
?>