<?php
include('dbconn.php');
$score = ret_score();
$name = ret_teamid();
echo '<tr>';
foreach($name as $n){
	echo '<td>';
		echo $n['team_name'];
	echo '</td>';
}
echo '</tr>';
	

?>