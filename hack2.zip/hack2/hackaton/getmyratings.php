

<html>
	<head>
		
		<meta http-equiv="refresh" content="2">
		<style>
			body{margin:0;padding:0;}
			table{margin:0;}
		</style>
	</head>
<body>
<?php

	include('dbconn.php');	
	if(!empty($_GET['judge_id'])){
		$judge_id=$_GET['judge_id'];
		$team = ret_user();
					
		echo "<table style=' width:100%;border-collapse:collapse;border:1px solid #c0c0c0'>";
			echo "<tr style=border:1px solid #c0c0c0'>";
				echo "<td>Group Names</td>";
				echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>Uniqueness</td>";	
				echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>Close to product</td>";	
				echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>Creativity</td>";	
				echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>Total</td>";	
				
			echo '</tr>';
			
			foreach($team as $t){
				echo "<tr style='border:1px solid #c0c0c0;padding:10px;background-color:#addce6'>";								
						echo "<td style='background-color:#7CFC00;text-align:center;border:1px solid #c0c0c0;padding:10px'>".$t['team_name']."</td>";							
						$row=getLastJudgeUpdate($t['team_id'],$judge_id);	
						echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>".$row['c1']."%</td>";
						echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>".$row['c2']."%</td>";
						echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>".$row['c3']."%</td>";
						$total=$row['c1']+$row['c2']+$row['c3'];
						echo "<td style='text-align:center;border:1px solid #c0c0c0;padding:10px'>".$total."%</td>";
				echo '</tr>';
			}		
		echo '</table>';
	}
?>
</body>
</html>