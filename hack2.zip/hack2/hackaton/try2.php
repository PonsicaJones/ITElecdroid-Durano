<?php
include 'dbconn.php';

$score =ret_score();
  
  echo "<table border=1 align=center>";
  echo "<th>C1</th>";
  echo "<th>C2</th>";
  echo "<th>C3</th>";

  foreach($score as $s) {
  echo "<tr>";
      foreach($s as $n){
	    echo "<td>".$n."</td>";
	  }
	echo "</tr>";
  }
  echo "</table>";
?>