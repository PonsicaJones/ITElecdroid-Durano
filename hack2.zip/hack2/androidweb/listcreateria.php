<?php
//for android client
	//database preliminaries
	
	$hostname='localhost';
	$username='root';
	$password='';
	//database name
	$database='ictcongress';
	//query variable
	$sql="SELECT * FROM createria";
	//connect your php program to the database server
	$conn=mysql_connect($hostname,$username,$password) or die('server not available');
	//select a database at the database server
	
	$db=mysql_select_db($database) or die('Database not available');
	//access a database table in the selected database
	$query=mysql_query($sql) or die('SQL Error');
	
	$container['createria']=array();
	while($row=mysql_fetch_array($query)){
		$item=array();
		$item['crea_id']=$row['crea_id'];
		$item['crea_name']=$row['crea_name'];
		$item['crea_total']=$row['crea_total'];
		array_push($container['createria'],$item);
	}
	echo json_encode($container);	
	mysql_close($conn);
?>