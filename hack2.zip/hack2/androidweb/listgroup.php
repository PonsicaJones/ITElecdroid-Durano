<?php
//for android client
	//database preliminaries
	
	$hostname='localhost';
	$username='root';
	$password='';
	//database name
	$database='ictcongress';
	//query variable
	$sql="SELECT * FROM teamm";
	//connect your php program to the database server
	$conn=mysql_connect($hostname,$username,$password) or die('server not available');
	//select a database at the database server
	
	$db=mysql_select_db($database) or die('Database not available');
	//access a database table in the selected database
	$query=mysql_query($sql) or die('SQL Error');
	
	$container['team']=array();
	while($row=mysql_fetch_array($query)){
		$item=array();
		$item['team_id']=$row['team_id'];
		$item['team_name']=$row['team_name'];

		array_push($container['team'],$item);
	}
	echo json_encode($container);	
	mysql_close($conn);
?>