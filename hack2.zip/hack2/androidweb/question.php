<?php
//for android client
	//database preliminaries
	
	$hostname='localhost';
	$username='root';
	$password='';
	//database name
	$database='exam';
	//query variable
	$sql="SELECT * FROM ques";
	//connect your php program to the database server
	$conn=mysql_connect($hostname,$username,$password) or die('server not available');
	//select a database at the database server
	
	$db=mysql_select_db($database) or die('Database not available');
	//access a database table in the selected database
	$query=mysql_query($sql) or die('SSQL Error');
	
	$container['question']=array();
	while($row=mysql_fetch_array($query)){
		$item=array();
		$item['qid']=$row['qid'];
		$item['question']=$row['question'];
		$item['choice1']=$row['choice1'];
		$item['choice2']=$row['choice2'];
		$item['choice3']=$row['choice3'];
		$item['choice4']=$row['choice4'];	
		array_push($container['question'],$item);
	}
	echo json_encode($container);	
	mysql_close($conn);
?>