<?php
	$hostname='localhost';
	$username='root';
	$password='';
	//database name
	$database='ictcongress';
	//query variable

	//connect your php program to the database server
	$conn=mysql_connect($hostname,$username,$password) or die('server not available');
	//select a database at the database server
	
	$db=mysql_select_db($database) or die('Database not available');
	//access a database table in the selected database

	if(!empty($_GET['username']) && !empty($_GET['password'])){
		$username = $_GET['username'];
		$password = $_GET['password'];
		
		
		$sql="SELECT * FROM judge where username ='$username' and password='$password'";
		$query=mysql_query($sql) or die('SSQL Error');
		$message = (mysql_num_rows($query) == 1)?"Login Successfully":" Login Failed";
		
		echo $message;
	}
	else echo 'Login Error';
?>