<?php	//scriptlet tag

	//this script, accepts querystring data(add-on data on the URL)
	//check if there are actually arriving from the client
	
	if(!empty($_GET['name']) && !empty($_GET['username']) && !empty($_GET['password'])){
	
		$name=$_GET['name'];
		$user=$_GET['username'];
		$pass=$_GET['password'];
		
		$hostname='localhost';
		$username='root';
		$password='';
		//database name
		$database='ictcongress';
		//query variable
		
		$sql="INSERT into judge (judge_name,username, password) values('$name','$user','$pass')";
		//connect your php program to the database server
		$conn=mysql_connect($hostname,$username,$password) or die('server not available');
		//select a database at the database server
		
		$db=mysql_select_db($database) or die('Database not available');
		//access a database table in the selected database
		$query=mysql_query($sql) or die('SSQL Error');
		
		
		mysql_close($conn);
			echo 'New Judge Added added'; //send reply to client
		}
		else echo 'Please fill all fields'; //send reply to client
	
?>

