package com.example.studentregistration;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.example.studentweb.R;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class MainActivity extends Activity implements OnClickListener, OnItemSelectedListener {
	EditText txtFname, txtLname, txtIdno;
	Button btnAdd, btnCancel;
	Spinner cboCourse, cboYear, cboCampus;
	private String selectedCourse;
	private String selectedYear;
	private String selectedCampus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        this.txtIdno = (EditText) this.findViewById(R.id.editText1);
        this.txtLname = (EditText) this.findViewById(R.id.editText2);
        this.txtFname = (EditText) this.findViewById(R.id.editText3);
        
        this.cboCourse = (Spinner) this.findViewById(R.id.spinner1);
        this.cboCourse = (Spinner) this.findViewById(R.id.spinner2);
        this.cboCampus = (Spinner) this.findViewById(R.id.spinner3);
        this.btnAdd = (Button) this.findViewById(R.id.button2);
        this.btnCancel = (Button) this.findViewById(R.id.button1);
        
        this.cboCourse.setOnItemSelectedListener(this);
        this.cboYear.setOnItemSelectedListener(this);
        this.cboCampus.setOnItemSelectedListener(this);
        this.btnAdd.setOnClickListener(this);
        this.btnCancel.setOnClickListener(this);
        
    }
    
	@Override
	public void onClick(View arg0) {
		int id=arg0.getId();
		switch(id){
		case R.id.button1:
			
			String idno=this.txtIdno.getText().toString();
			String lname=this.txtLname.getText().toString();
			String fname=this.txtFname.getText().toString();
			//clean the name, put %20 character for two worded names			
			String[] mlname=lname.split("\\ "); //check for space between name words
			StringBuffer cleanLname=new StringBuffer();
			for(String s:mlname){
				cleanLname.append(s).append("%20");
			}
			
			String[] mfname=fname.split("\\ "); //check for space between name words
			StringBuffer cleanFname=new StringBuffer();
			for(String s:mfname){
				cleanFname.append(s).append("%20");
			}	
			
			try {
				URL url=new URL("http://10.0.2.2/student/addstudent.php?idno="+idno+"&lname="+cleanLname.toString()+"&fname="+cleanFname.toString()+"&course="+selectedCourse+"&year="+selectedYear+"&campus="+selectedCampus);
				HttpURLConnection conn=(HttpURLConnection) url.openConnection();
				//receive the server response
				InputStream is=conn.getInputStream();
				int c=0;
				StringBuffer sb=new StringBuffer();
				while((c=is.read())!=-1){					
					sb.append((char)c);					
				}
				//after receive, close all streams
				is.close();
				//disconnect the server
				conn.disconnect();
				
				
				Toast.makeText(this, sb.toString(), Toast.LENGTH_SHORT).show();
				
			
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		case R.id.button2:
			//clear all fields, set cursor to idno field
			this.txtIdno.setText("");
			this.txtLname.setText("");
			this.txtFname.setText("");
			this.cboCampus.setSelection(0);
			this.cboCourse.setSelection(0);
			this.cboYear.setSelection(0);
			this.txtIdno.requestFocus();
		}	
		
	}
	
	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		selectedCourse=this.cboCourse.getItemAtPosition(arg2).toString();
		selectedYear=this.cboYear.getItemAtPosition(arg2).toString();
		selectedCampus=this.cboCampus.getItemAtPosition(arg2).toString();
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}


}

