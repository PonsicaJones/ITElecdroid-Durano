package com.example.responder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SmsReciever extends BroadcastReceiver{
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		try {
			
			Bundle b = intent.getExtras();
	//		String number = null, body = null;
			Toast.makeText(context, "asdfasd", Toast.LENGTH_LONG).show();
			Object[] pdus = (Object[]) b.get("pdus");
		
		
				for(int i = 0; i < pdus.length; i++){
					SmsMessage sms = SmsMessage.createFromPdu((byte[])pdus[i]);
					String number = sms.getDisplayOriginatingAddress().toString();
					String body = sms.getDisplayMessageBody().toString();		
					Toast.makeText(context, body+" "+number, Toast.LENGTH_LONG).show();
				}	  
	//					SmsManager smsm = SmsManager.getDefault();
	//					smsm.sendTextMessage(number, null, "wew ahahaha", null, null);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "asdf", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
	
	}
}
