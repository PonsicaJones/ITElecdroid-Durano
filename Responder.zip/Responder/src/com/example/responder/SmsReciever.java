package com.example.responder;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SmsReciever extends BroadcastReceiver implements LocationListener {
	private LocationManager locman;
	private Criteria criteria;
	private String provider;
	private Location location;

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		try {			
			Bundle b = intent.getExtras();
			String number = "", body = "";
	
			Object[] pdus = (Object[]) b.get("pdus");
			
				for(int i = 0; i < pdus.length; i++){
					SmsMessage sms = SmsMessage.createFromPdu((byte[])pdus[i]);
					 number = sms.getDisplayOriginatingAddress().toString();
					 body = sms.getDisplayMessageBody().toString();		
				
				}	  
				if(body.equals("Uli na nak")){
					locman = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
					criteria = new Criteria();
					
					criteria.setAccuracy(Criteria.ACCURACY_MEDIUM);
					criteria.setPowerRequirement(Criteria.ACCURACY_MEDIUM);
						
					provider = locman.getBestProvider(criteria, false);
					locman.requestLocationUpdates(provider, 1, 10, this);
					
					location = locman.getLastKnownLocation(provider);
					
					if(provider != null){
						Toast.makeText(context, "Message: "+ body+" Sender: "+number+"provider: "+provider, Toast.LENGTH_LONG).show();				
						SmsManager smsm = SmsManager.getDefault();
						String lat = String.format("%.3f", location.getLatitude());
						String lng = String.format("%.3f", location.getLongitude());
						smsm.sendTextMessage(number, null, "padong nako uli ma naa pako sa Latitude: "+lat +" Longtitude: "+lng +" palihug lang ug compute ma", null, null);
					}else{
						AlertDialog.Builder builder = new AlertDialog.Builder(context);
						builder.setTitle("Information ");
						builder.setMessage("Please Turn on GPS");
						builder.setPositiveButton("ok", null);
						builder.setNegativeButton("cancel", null);
						AlertDialog dialog = builder.create();
							dialog.show();
					}
				}else{
					Toast.makeText(context, "Message: "+ body+" Sender: "+number+"provider: "+provider, Toast.LENGTH_LONG).show();		
					SmsManager smsm = SmsManager.getDefault();					
					smsm.sendTextMessage(number, null, "padong nako uli ma naa pako", null, null);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}
	
	}

	@Override
	public void onLocationChanged(Location arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		// TODO Auto-generated method stub
		
	}
}
