package com.example.midtermlab;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class UpdatePerson extends Activity implements OnClickListener{
	ImageView iv;
	Button btnSubmit, btnCancel;
	EditText txtName;
	Uri uri;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.updatepersonlayout2);
		
		this.txtName =  (EditText) this.findViewById(R.id.editText1);
		this.btnSubmit = (Button) this.findViewById(R.id.button1);
		this.btnCancel = (Button) this.findViewById(R.id.button2);
		this.iv = (ImageView) this.findViewById(R.id.imageView1);
		
		this.iv.setOnClickListener(this);	
		this.btnSubmit.setOnClickListener(this);
		this.btnCancel.setOnClickListener(this);
		try{
			Intent intent = this.getIntent();
			Bundle b = intent.getExtras();
			if(b != null ){
				String updatename = b.getString("updatename"); 
				Uri r;
				r = b.getParcelable("updateimage");
				this.iv.setImageURI(r);
				this.txtName.setText(updatename);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	} 	
	@Override
	public void onClick(View arg0) {
		try{
			int id = arg0.getId();
			switch(id){
			case R.id.imageView1:
				Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				this.startActivityForResult(intent, 111);
				break;
			case R.id.button1:
				String name = txtName.getText().toString();
				intent = new Intent();
				if(uri != null && !name.equals("")){
					intent.putExtra("name", name);
					intent.putExtra("uri", uri);
					this.setResult(Activity.RESULT_OK, intent);
					
				}else{
					Toast.makeText(this, "Fill all the Fields", Toast.LENGTH_SHORT).show();
					break;
				}
			case R.id.button2:
				this.finish();
				break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
			
	}	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		try{
			super.onActivityResult(requestCode, resultCode, data);
			
			uri = data.getData();
			this.iv.setImageURI(uri);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
}
