package com.example.midtermlab;



import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class MainActivity extends Activity implements OnClickListener {
	ArrayList<Person> list = new ArrayList<Person>();
	ArrayList<Person> source = new ArrayList<Person>();
	ItemAdapter adapter;
	ListView lv;
	AdapterView.AdapterContextMenuInfo info;
	EditText txtSearch;
	static boolean flag = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        this.txtSearch = (EditText) this.findViewById(R.id.editText1);
        this.lv = (ListView) this.findViewById(R.id.listView1);
        this.adapter = new ItemAdapter(list,this);
        this.lv.setAdapter(adapter);
        this.registerForContextMenu(lv);
        this.txtSearch.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				flag = false;
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				 list.clear();
				Pattern p = Pattern.compile(arg0.toString());
				for(int i = 0; i < source.size(); i++){
					Matcher nameList = p.matcher(source.get(i).getName());
					if(nameList.find()){
						list.add(source.get(i));						
					}
					adapter.notifyDataSetChanged();
				}
			}
        	
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    
    public boolean isSearch(){
    	return false;
    }
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		try{
			Intent intent = new Intent(this,UpdatePerson.class);
			this.startActivityForResult(intent, 0);
		}catch(Exception e){
			e.printStackTrace();
		}
		return super.onOptionsItemSelected(item);
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		try{
			Bundle b = data.getExtras();
			Uri uri = b.getParcelable("uri");
			String name = b.getString("name");
			
			Person p = new Person(uri,name);
			switch(requestCode){
			case 0:
				source.add(p);
				list.add(p);
				break;
			case 1:
				list.set(info.position, p);
				source.set(info.position, p);
				break;
			}		
		adapter.notifyDataSetChanged();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		try{
			int id = item.getItemId();
			switch(id){
			case R.id.update:
				String itemSelectedName;
				Uri uri;

					 itemSelectedName = list.get(info.position).getName();
					 uri = list.get(info.position).getUri();

				
				Intent intent = new Intent(this,UpdatePerson.class);
				intent.putExtra("updatename", itemSelectedName);
				intent.putExtra("updateimage", uri);
				this.startActivityForResult(intent, 1);
				break;
			case R.id.delete:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setTitle("Message");
				builder.setMessage("Are you sure you want to delete "+list.get(info.position).getName()+" ?");
				builder.setPositiveButton("Ok", this);
				builder.setNegativeButton("Cancel", this);
				
				AlertDialog dialog = builder.create();
					dialog.show();
				break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return super.onContextItemSelected(item);
	}


	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		getMenuInflater().inflate(R.menu.itemcontextmenu, menu);
		info = (AdapterContextMenuInfo) menuInfo;
		String itemSelectedName = list.get(info.position).getName();
//		menu.setHeaderIcon(R.drawable.info);
		menu.setHeaderTitle(itemSelectedName);
	}


	@Override
	public void onClick(DialogInterface arg0, int arg1) {
		 //TODO Auto-generated method stub
		try{
			switch(arg1){
			case DialogInterface.BUTTON_POSITIVE:
				list.remove(list.get(info.position));
				source.remove(source.get(info.position));
				adapter.notifyDataSetChanged();
					Toast.makeText(this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
			break;
			case DialogInterface.BUTTON_NEGATIVE:
				this.finish();
			break;
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
   

}
