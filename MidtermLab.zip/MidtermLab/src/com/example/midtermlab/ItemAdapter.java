package com.example.midtermlab;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class ItemAdapter extends BaseAdapter {
	ArrayList<Person> list = new ArrayList<Person>();
	Context context;
	LayoutInflater inflater;
	
	public ItemAdapter(ArrayList<Person> list, Context context) {
		super();
		this.list = list;
		this.context = context;
		this.inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return list.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int arg0, View arg1, ViewGroup arg2) {
		ItemHandler handler = null;
		if(list.size() % 2 == 0){
		
			if(arg1==null){
				arg1 = inflater.inflate(R.layout.itemlayout2, null);
				handler = new ItemHandler();
				handler.iv =(ImageView) arg1.findViewById(R.id.imageView1);
				handler.tv =  (TextView) arg1.findViewById(R.id.textView1);
				arg1.setTag(handler);
			}else handler = (ItemHandler) arg1.getTag();
				handler.iv.setImageURI(list.get(arg0).getUri());
				handler.tv.setText(list.get(arg0).getName());		
		}else{
			if(arg1==null){
				arg1 = inflater.inflate(R.layout.itemlayout, null);
				handler = new ItemHandler();
				handler.iv =(ImageView) arg1.findViewById(R.id.imageView1);
				handler.tv =  (TextView) arg1.findViewById(R.id.textView1);
				arg1.setTag(handler);
			}else handler = (ItemHandler) arg1.getTag();
				handler.iv.setImageURI(list.get(arg0).getUri());
				handler.tv.setText(list.get(arg0).getName());		
		}
		return arg1;
	}
	
	static class ItemHandler{
		ImageView iv;
		TextView tv;
	}

}
