package com.example.weblogin;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class AddStudent extends Activity implements OnClickListener{
	EditText txtFname, txtLname, txtIdno;
	Button btnAdd, btnCancel;
	Spinner cboCourse, cboYear, cboCampus;

	private String selectedCourse;
	private String selectedYear;
	private String selectedCampus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addlayout);
        
        this.txtIdno = (EditText) this.findViewById(R.id.editText1);
        this.txtLname = (EditText) this.findViewById(R.id.editText2);
        this.txtFname = (EditText) this.findViewById(R.id.editText3);
        this.cboCourse = (Spinner) this.findViewById(R.id.spinner1);     
        this.cboYear = (Spinner) this.findViewById(R.id.spinner2);
        this.cboCampus = (Spinner) this.findViewById(R.id.spinner3);
        this.btnAdd = (Button) this.findViewById(R.id.button2);
        this.btnCancel = (Button) this.findViewById(R.id.button1);
        txtIdno.setError("Please Enter Idno");
        txtLname.setError("Please Enter Idno");
        txtFname.setError("Please Enter Idno");

        
        this.cboCourse.setOnItemSelectedListener(new OnItemSelectedListener() {
			

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				selectedCourse=cboCourse.getItemAtPosition(arg2).toString();	
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});    
//        this.cboCampus.setOnItemSelectedListener(this);
        this.cboYear.setOnItemSelectedListener(new OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				selectedYear=cboYear.getItemAtPosition(arg2).toString();
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
        	
        	
        });
        this.cboCampus.setOnItemSelectedListener(new OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				selectedCampus=cboCampus.getItemAtPosition(arg2).toString();
				
			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}});
        this.btnAdd.setOnClickListener(this);
        this.btnCancel.setOnClickListener(this);

        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
    }
    
	@Override
	public void onClick(View arg0) {
		int id=arg0.getId();
		switch(id){
		case R.id.button2:
			
			String idno=this.txtIdno.getText().toString();
			String lname=this.txtLname.getText().toString();
			String fname=this.txtFname.getText().toString();
			try {
				URL url=new URL("http://10.0.2.2/androidweb/addstudent.php?idno="+idno+"&lname="+lname+"&fname="+fname+"&course="+selectedCourse+"+&year="+selectedYear+"&campus="+selectedCampus);
				HttpURLConnection conn=(HttpURLConnection) url.openConnection();
				//receive the server response
				InputStream is=conn.getInputStream();
				int c=0;
				StringBuffer sb=new StringBuffer();
				while((c=is.read())!=-1){					
					sb.append((char)c);					
				}
				//after receive, close all streams
				is.close();
				//disconnect the server
				conn.disconnect();
				
				
				Toast.makeText(this, sb.toString(), Toast.LENGTH_SHORT).show();
				
					Intent intent = new Intent(this, ListLang.class);
					startActivity(intent);
//					new ListLang().retrieve();
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		case R.id.button1:
			//clear all fields, set cursor to idno field
			this.txtIdno.setText("");
			this.txtLname.setText("");
			this.txtFname.setText("");
			this.cboCourse.setSelection(0);
			this.cboYear.setSelection(0);
			this.cboCampus.setSelection(0);
			this.txtIdno.requestFocus();
			break;
		}
	}
}
