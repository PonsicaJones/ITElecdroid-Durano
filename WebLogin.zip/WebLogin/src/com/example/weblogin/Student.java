package com.example.weblogin;

public class Student {
	private String idno;
	private String lastname;
	private String firstname;
	private String campus;
	private String year;
	private String course;
	
	public Student(String idno, String lastname, String firstname, String campus,
			String year, String course) {
		super();
		this.idno = idno;
		this.lastname = lastname;
		this.firstname = firstname;
		this.campus = campus;
		this.year = year;
		this.course = course;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public String getIdno() {
		return idno;
	}

	public void setIdno(String idno) {
		this.idno = idno;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getCampus() {
		return campus;
	}

	public void setCampus(String campus) {
		this.campus = campus;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}
	
	
}
