package com.example.weblogin;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;

import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.AdapterContextMenuInfo;

public class ListLang extends Activity{
	ArrayList<Student> list = new ArrayList<Student>();
	ItemAdapter adapter;
	ListView lv;
//	String jsonString = "";
	Button btnAdd;
	AdapterView.AdapterContextMenuInfo info;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listlayout);		
		lv = (ListView) this.findViewById(R.id.listView1);

        adapter = new ItemAdapter(list,this);
        this.lv.setAdapter(adapter);
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
        retrieve();
        this.registerForContextMenu(lv);
	}
	
	public void retrieve(){
		
		 try {
				URL url = new URL("http://10.0.2.2/androidweb/listforandroid.php");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				
				InputStream is = conn.getInputStream();
				StringBuffer sb = new StringBuffer();
				int c = 0;
				while((c=is.read())!=-1){
					sb.append((char)c);
				}
				
				conn.disconnect();
				is.close();
				
				String jsonString = sb.toString();
				JSONObject json = new JSONObject(jsonString);
				JSONArray studentArray = json.getJSONArray("student");

				for(int i = 0; i < studentArray.length(); i++){
					JSONObject student = (JSONObject) studentArray.get(i);
						Student s = new Student();
					    s.setIdno(student.getString("idno"));
						s.setLastname(student.getString("familyname"));
						s.setFirstname(student.getString("givenname"));
						s.setCourse(student.getString("course"));
						s.setYear(student.getString("yearlevel"));
						s.setCampus(student.getString("campus"));
						list.add(s);
				}
					this.adapter.notifyDataSetChanged();
			        			
				Toast.makeText(this, studentArray.length()+"", Toast.LENGTH_LONG).show();
			} catch (MalformedURLException e) {
				Toast.makeText(this, "m", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (IOException e) {
				Toast.makeText(this, "i", Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        adapter.notifyDataSetChanged();
	}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);      
        return true;
    }
    
    @Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		try{
			Intent intent = new Intent(this,AddStudent.class);
			this.startActivity(intent);
		}catch(Exception e){
			e.printStackTrace();
		}
		return super.onOptionsItemSelected(item);
	}
    
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		
		getMenuInflater().inflate(R.menu.mymenucontext, menu);
		info = (AdapterContextMenuInfo) menuInfo;
		String selectedItem = list.get(info.position).getIdno();		
		menu.setHeaderTitle(selectedItem);
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case R.id.delete:
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setTitle("Confirmation");
				builder.setMessage("Are you sure you want to delete this? ");
				builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						try {
						String selectedItem = list.get(info.position).getIdno();
						URL url = new URL("http://10.0.2.2/androidweb/deleteStudent.php?idno="+selectedItem);
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						
						InputStream is = conn.getInputStream();
						StringBuffer sb = new StringBuffer();
						int c = 0;
						
						
						while((c=is.read())!=-1){
							sb.append((char)c);
						}
						Toast.makeText(ListLang.this, sb.toString(), Toast.LENGTH_LONG).show();
						
						Intent intent = new Intent(ListLang.this,ListLang.class);
						startActivity(intent);
						
						conn.disconnect();
						is.close();
						
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						
					}
				});
				
				AlertDialog dialog = builder.create();
				dialog.show();
					
			break;
			
		case R.id.update:
			String idnoSelected = list.get(info.position).getIdno();
			String lastSelected = list.get(info.position).getLastname();
			String firstSelected = list.get(info.position).getFirstname();
			String courseSelected = list.get(info.position).getCourse();
			String yearSelected = list.get(info.position).getYear();
			String campusSelected = list.get(info.position).getCampus();
			
			Intent intent = new Intent(this, AddStudent.class);
			intent.putExtra("idno",idnoSelected);
			intent.putExtra("lastSelected",lastSelected);
			intent.putExtra("firstSelected",firstSelected);
			intent.putExtra("courseSelected",courseSelected);
			intent.putExtra("yearSelected",yearSelected);
			intent.putExtra("campusSelected",campusSelected);
			startActivityForResult(intent,1000);
			break;
		}
		return super.onContextItemSelected(item);
	}
	
}
